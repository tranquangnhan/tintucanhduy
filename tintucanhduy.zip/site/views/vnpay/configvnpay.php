<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$vnp_TmnCode = "WBXUAR2N"; //Mã website tại VNPAY
$vnp_HashSecret = "MMNURKPPAXBRAMUAWRVQRIJBPWHEAVGA"; //Chuỗi bí mật
$vnp_Url = "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html";
$vnp_Returnurl = "http://localhost/asmphp2/thanh-toan-thanh-cong/";

// 9704198526191432198

// NGUYEN VAN A

// 07/15

// 123456
