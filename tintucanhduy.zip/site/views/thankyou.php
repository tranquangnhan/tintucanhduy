  <!-- Main Wrapper Start -->
  <main class="main-content-wrapper">
            <div class="error-area pt--90 pt-xl--70 pb--120 pb-xl--100 pb-lg--95 pb-sm--90">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-xl-12 col-lg-12 text-center">
                            <div class="error thankyou">
                                <h1>Cảm Ơn</h1>
                                <h2>Cảm ơn bạn đã đặt hàng ở shop !</h2>
                                <p>Đây là điều tuyệt vời nhất mà shop nhận được, xin chân thành cảm ơn bạn, chúc bạn có một ngày mới tốt lành!</p>
                           
                                <a href="index.php" class="btn">Trở về trang chủ</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!-- Main Wrapper End -->