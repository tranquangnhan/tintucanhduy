<?php
    class thongbao{

    }
    include_once "views/thongbao.php";
?>